﻿# comp229-crud

You will need to have a local mongodb up and then you can run these both commands on the root folder of this project.

```
npm i
npx nodemon
```
